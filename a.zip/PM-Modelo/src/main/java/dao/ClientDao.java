/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.math.BigDecimal;
import modelo.Client;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;
import javax.sql.DataSource;
import modelo.Cart;
import modelo.Product;

/**
 *
 * @author edria
 */
public class ClientDao implements DaoInterfaz {

    public static ClientDao dao;

    public static ClientDao getInstance() {
        if (dao == null) {
            dao = new ClientDao();
        }
        return dao;
    }

    @Override
    public Collection<Client> findByName(String name, DataSource ds) throws SQLException {
        Collection<Client> c = new ArrayList<>();
        Connection con = ds.getConnection();
        PreparedStatement ps = con.prepareStatement("select * from CLIENTS where name = ?");
        ps.setString(1, name);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Client cliente = this.composeClient(rs);
            c.add(cliente);
        }
        return c;
    }

    @Override
    public Optional<Client> findByMail(String mail, DataSource ds) throws SQLException {
        Optional<Client> cliente;
        try (Connection con = ds.getConnection()) {
            cliente = null;
            PreparedStatement ps = con.prepareStatement("select * from CLIENTS where mail = ?");
            ps.setString(1, mail);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                cliente = Optional.of(this.composeClient(rs));
            }
            rs.close();
        }
        return cliente == null ? Optional.empty() : cliente;
    }

    @Override
    public Optional<Client> findById(Long id, DataSource ds) throws SQLException {
        Optional<Client> p = Optional.empty(); //cambiar como en por DNI
        try (Connection con = ds.getConnection(); PreparedStatement ps = con.prepareStatement("select * from CLIENTS where id_client = ?")) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                p = Optional.of(this.composeClient(rs));
            }
            rs.close();
        }
        return p;
    }

    @Override
    public Collection<Client> findAll(DataSource ds) throws SQLException {
        Collection<Client> c;
        try (Connection con = ds.getConnection()) {
            c = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement("select * from CLIENTS")) {
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Client p = this.composeClient(rs);
                    c.add(p);
                }
                rs.close();
            }
        }
        return c;
    }

    @Override
    public void insert(Client entity, DataSource ds) throws SQLException {
        try (Connection con = ds.getConnection(); PreparedStatement ps = con.prepareStatement("insert into CLIENTS (id_client, name, mail, password, discount) values(seq_client.nextval, ?, ?, ?, ?)")) {
            ps.setString(1, entity.getName());
            ps.setString(2, entity.getEmail());
            ps.setString(3, entity.getPassword());
            if (entity.getDiscount() != null) {
                ps.setInt(4, entity.getDiscount());
            } else {
                ps.setNull(4, java.sql.Types.NULL);
            }
            ps.executeUpdate();
        }
    }

    @Override
    public int update(Client entity, DataSource ds) throws SQLException {
        try (Connection con = ds.getConnection(); PreparedStatement ps = con.prepareStatement("update CLIENTS set name = ?, mail = ?, password = ?, discount = ? where id_client = ?")) {
            ps.setString(1, entity.getName());
            ps.setString(2, entity.getEmail());
            ps.setString(3, entity.getPassword());
            ps.setInt(4, entity.getDiscount());
            ps.setLong(5, entity.getId());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(Client entity, DataSource ds) throws SQLException {
        try (Connection con = ds.getConnection(); PreparedStatement ps = con.prepareStatement("delete from CLIENTS where id_client = ")) {
            ps.setLong(1, entity.getId());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(Long id, DataSource ds) throws SQLException {
        try (Connection con = ds.getConnection(); PreparedStatement ps = con.prepareStatement("delete from CLIENTS where id_client = ")) {
            ps.setLong(1, id);
            return ps.executeUpdate();
        }
    }

    private Client composeClient(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id_client");
        String name = rs.getString("name");
        String email = rs.getString("mail");
        String password = rs.getString("password");
        Integer discount = rs.getObject("discount", Integer.class);
        Integer purchases = rs.getObject("purchases", Integer.class);
        return new Client(id, name, email, password, discount, purchases);
    }

    /*NUEVO*/
    public void buy(Long idc, Long idp, BigDecimal price, Integer nProducts, DataSource ds) throws SQLException {
        Connection con = ds.getConnection();
        PreparedStatement ps = con.prepareStatement("insert into purchases(id_purchase, id_buyer, username, price) select 'p' || lpad(seq_purchases.nextval, 3, '0'), c.id_client, c.name, p.price from clients c, products p where c.id_client = ? and p.id_product = ?;");
        PreparedStatement ps2 = con.prepareStatement("insert into purchases_products(id_purchase_mid, id_product_mid, n_products) select pr.id_purchase, p.id_product, ? from products p, purchases pr where p.id_product = ?; ");
        PreparedStatement ps3 = con.prepareStatement("insert into clients(purchases) values ((select purchases from clients where id_client = ? + 1) where id_client = ?;");
        ps.setLong(1, idc);
        ps.setLong(2, idp);
        ps2.setInt(1, nProducts);
        ps2.setLong(2, idp);
        ps3.setLong(1, idc);
        ps3.setLong(2, idc);
        ps.executeUpdate();
        ps2.executeUpdate();
        ps3.executeUpdate();
        ps.close();
        ps2.close();
        ps3.close();

        //Codigo viejo, por si acaso el nuevo no funciona
//        PreparedStatement ps = con.prepareStatement("insert into PURCHASES (id_purchase, id_buyer, username, price) values (seq_purchases.nextval, ?, ?, ?)");
//        PreparedStatement ps2 = con.prepareStatement("insert into PURCHASES_PRODUCTS (id_purchase_mid, id_product_mid, n_products) values (seq_purchases.currval, ?, ?)");
//            ps.setString(3, name);
//            ps.setBigDecimal(4, price);
    }

//    public void addCart(Cart c, Product p, DataSource ds) throws SQLException {
//        Connection con = ds.getConnection();
//        PreparedStatement ps = con.prepareStatement("delete from CLIENTS where id_client = ");
    ////        ps.setLong(1, id);
////        return ps.executeUpdate();
//    }
//
//    public boolean checkCart(Long id, DataSource ds) throws SQLException {
//        Connection con = ds.getConnection();
//        PreparedStatement ps = con.prepareStatement("select from CART where id_cart = ?");
//        ps.setLong(1, id);
//        ResultSet rs = ps.executeQuery();
//        boolean check = false;
//        while (rs.next()) {
//            check = true;
//        }
//        rs.close();
//        ps.close();
//        return check;
//    }

    public boolean checkPurchase(Long id, DataSource ds) throws SQLException {
        try (Connection con = ds.getConnection(); PreparedStatement ps = con.prepareStatement("select * from purchases where id_purchase = ?")) {
            ps.setLong(1, id);
            boolean check = false;
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                check = true;
            }
            return check;
        }
    }

    private Product composeProduct(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id_product");
        String name = rs.getString("name");
        BigDecimal price = rs.getBigDecimal("price");
        Integer stock = rs.getObject("stock", Integer.class);
        String category = rs.getString("category");
        String color = rs.getString("color");
        String talla = rs.getString("talla");
        String description = rs.getString("description");
        return new Product(id, name, price, stock, category, color, talla, description);
    }

    public ArrayList getPurchases(Client c, DataSource ds) throws SQLException {
        try (Connection con = ds.getConnection(); PreparedStatement ps = con.prepareStatement("select * from purchases where id_buyer = ?")) {
            ps.setLong(1, c.getId());
            ResultSet rs = ps.executeQuery();
            ArrayList<Product> retorno = new ArrayList();
            while (rs.next()) {
                retorno.add(this.composeProduct(rs));
            }
            return retorno;
        }
    }
}
