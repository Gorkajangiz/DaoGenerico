package dao;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Optional;
import javax.sql.DataSource;

public interface Dao<T> {

    Collection<T> findAll(DataSource ds) throws SQLException;

    Optional<T> findById(Long id, DataSource ds) throws SQLException;

    void insert(T entitys, DataSource ds) throws SQLException;

    int update(T entity, DataSource ds) throws SQLException;

    int delete(T entity, DataSource ds) throws SQLException;

    int delete(Long id, DataSource ds) throws SQLException;
}
