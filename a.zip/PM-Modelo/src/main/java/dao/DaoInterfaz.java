/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Optional;
import javax.sql.DataSource;
import modelo.Client;

/**
 *
 * @author edria
 */
public interface DaoInterfaz extends Dao<Client> {

    Collection<Client> findByName(String name, DataSource ds) throws SQLException;

    Optional<Client> findByMail(String mail, DataSource ds) throws SQLException;

}
