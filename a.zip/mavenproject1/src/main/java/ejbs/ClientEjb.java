/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatefulEjbClass.java to edit this template
 */
package ejbs;

import dao.ClientDao;
import static ejbs.ClientEjb.Register.FIELDS_EMPTY;
import static ejbs.ClientEjb.Register.REGISTER_EMAIL_IN_USE;
import static ejbs.ClientEjb.Register.REGISTER_SUCCESS;
import jakarta.annotation.Resource;
import jakarta.ejb.Stateful;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import modelo.Cart;
import modelo.Client;
import modelo.Product;

/**
 *
 * @author edria
 */
@Stateful
public class ClientEjb implements ClientEjbLocal {

    @Resource(name = "ds")
    private DataSource ds;

    public static enum Login {
        LOGIN_SUCCESS, LOGIN_EMAIL_FAILURE, LOGIN_PASSWD_FAILURE
    }

    public static enum Register {
        REGISTER_SUCCESS, REGISTER_EMAIL_IN_USE, FIELDS_EMPTY
    }

    @Override
    public Collection<Client> getClients() {
        Collection<Client> clients = new ArrayList<>();
        try {
            clients = ClientDao.getInstance().findAll(ds);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return clients;
    }

    @Override
    public Collection<Client> getByName(String name) {
        Collection<Client> clients = new ArrayList<>();
        try {
            clients = ClientDao.getInstance().findByName(name, ds);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return clients;
    }

    @Override
    public Collection<Client> getByMail(String mail) {
        Collection<Client> clients = new ArrayList<>();
        try {
            clients = ClientDao.getInstance().findByName(mail, ds);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return clients;
    }

    @Override
    public void insert(Client c) {
        try {
            ClientDao.getInstance().insert(c, ds);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public int deleteClient(Client c) {
        int i = 0;
        try {
            i = ClientDao.getInstance().delete(c, ds);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return i;
    }

    @Override
    public int deleteId(Long id) {
        int i = 0;
        try {
            i = ClientDao.getInstance().delete(id, ds);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return i;
    }

    @Override
    public int update(Client c) {
        int i = 0;
        try {
            i = ClientDao.getInstance().update(c, ds);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return i;
    }

    @Override
    public Login login(String email, String password) {
        Optional<Client> retorno;
        Login vuelta = null;
        try {
            retorno = ClientDao.getInstance().findByMail(email, ds);
            if (retorno.isPresent()) {
                if (this.passwordCorrector(retorno.get().getPassword()).equals(password)) {
                    vuelta = Login.LOGIN_SUCCESS;
                } else {
                    vuelta = Login.LOGIN_PASSWD_FAILURE;
                }
            } else {
                vuelta = Login.LOGIN_EMAIL_FAILURE;
            }
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return vuelta;
    }

    @Override
    public Register register(String email, String password, String name) {
        Register retorno = null;
        try {
            if (!ClientDao.getInstance().findByMail(email, ds).isPresent()) {
                if (email.isBlank() || name.isBlank() || password.isBlank()) {
                    retorno = FIELDS_EMPTY;
                } else {
                    String temp = this.passwordScrambler(password);
                    ClientDao.getInstance().insert(new Client(null, email, name, temp, 0, 0), ds);
                    retorno = REGISTER_SUCCESS;
                }
            } else {
                retorno = REGISTER_EMAIL_IN_USE;
            }
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return retorno;
    }

    @Override
    public String passwordScrambler(String clientPassword) {
        String password = "";
        int offset = clientPassword.charAt(1) % 10 + 5;
        password += (char) (offset + 33);
        for (int i = 0; i < clientPassword.length(); i++) {
            char c = clientPassword.charAt(i);
            c += offset;
            password += c;
        }
        return password;
    }

    @Override
    public String passwordCorrector(String scrambledPassword) {
        String original = "";
        int offset = scrambledPassword.charAt(0) - 33;
        for (int i = 1; i < scrambledPassword.length(); i++) {
            char c = scrambledPassword.charAt(i);
            c -= offset;
            original += c;
        }
        return original;
    }

    /*NUEVO*/
    public void buy(Client c, Product p, BigDecimal price, Integer quantity) {
        try {
            ClientDao.getInstance().buy(c.getId(), p.getId(), price, quantity, ds);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

//    public void addCart(Cart c, Product p) {
//        try {
//            if (ClientDao.getInstance().checkCart(c.getId(), ds)) {
//                ClientDao.getInstance().addCart(c, p, ds);
//            } else {
//                Cart c1 = new Cart(0);
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(ClientEjb.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
    public int checkPurchase(Long id) {
        int retorno = 0;
        try {
            if (ClientDao.getInstance().checkPurchase(id, ds)) {
                retorno = 1;
            } else {
                retorno = 0;
            }
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return retorno;
    }

    public ArrayList getPurchases(Client c) {
        ArrayList<Product> list = null;
        try {
            list = ClientDao.getInstance().getPurchases(c, ds);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return list;
    }
}
