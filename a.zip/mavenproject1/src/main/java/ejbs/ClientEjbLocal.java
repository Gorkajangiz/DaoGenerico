/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionLocal.java to edit this template
 */
package ejbs;

import ejbs.ClientEjb.Login;
import ejbs.ClientEjb.Register;
import jakarta.ejb.Local;
import java.util.Collection;
import modelo.Client;

/**
 *
 * @author edria
 */
@Local
public interface ClientEjbLocal {

    Login login(String email, String password);

    Register register(String email, String password, String name);

    public Collection<Client> getClients();

    public Collection<Client> getByName(String name);

    public Collection<Client> getByMail(String mail);

    public void insert(Client c);

    public int deleteClient(Client c);

    public int deleteId(Long id);

    public int update(Client c);

    public String passwordScrambler(String password);

    public String passwordCorrector(String password);
}
