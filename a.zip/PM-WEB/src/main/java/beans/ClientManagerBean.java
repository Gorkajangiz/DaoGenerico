/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package beans;

import ejbs.ClientEjbLocal;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import modelo.Client;

/**
 *
 * @author edria
 */
@Named(value = "clientManagerBean")
@SessionScoped
public class ClientManagerBean implements Serializable {

    @EJB
    private ClientEjbLocal clientEjb;

    Collection<Client> clients;
    List<String> errores;
    Client client;
    Boolean deleteDlg;

    public ClientManagerBean() {
    }

    @PostConstruct
    public void init() {
        clients = new ArrayList<>();
        client = new Client(); //Utilizar el loginBean.client.password en lugar del loginBean.password
        errores = new ArrayList<>();
        deleteDlg = false;
        initClients();
    }

    private void initClients() {
        clients = clientEjb.getClients();
    }

    public void borrar() {
        clientEjb.deleteId(client.getId());
        initClients();
    }

    public void editar() {
        client.setName(client.getName());
        client.setDiscount(client.getDiscount());
        clientEjb.update(client);
        initClients();
    }

    public void openDeleteDlg() {
        deleteDlg = true;
    }

    public void closeDeleteDlg() {
        deleteDlg = false;
    }

    public boolean hasError(String error) {
        return errores.contains(error);
    }

    public Collection<Client> getClients() {
        return clients;
    }

    public void setClients(Collection<Client> clients) {
        this.clients = clients;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Boolean getDeleteDlg() {
        return deleteDlg;
    }

    public void setDeleteDlg(Boolean deleteDlg) {
        this.deleteDlg = deleteDlg;
    }

}
