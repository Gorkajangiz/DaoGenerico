/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package beans;

import ejbs.ClientEjb;
import ejbs.ClientEjbLocal;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import modelo.Client;

/**
 *
 * @author edria
 */
@Named(value = "loginBean")
@SessionScoped
public class LoginBean implements Serializable {

    @EJB
    private ClientEjbLocal clientEjb;

    Collection<Client> clients;
    List<String> errores;
    Client client;
    String email;
    String username;
    String password;
    String cpassword;

    public LoginBean() {
    }

    @PostConstruct
    public void init() {
        clients = new ArrayList<>();
        client = new Client(); //Utilizar el loginBean.client.password en lugar del loginBean.password
        email = "";
        username = "";
        password = "";
        cpassword = "";
        errores = new ArrayList<>();
        initClients();
    }

    private void initClients() {
        clients = clientEjb.getClients();
    }

    public String login() {
        errores.clear();
        //switch sirve para asignar valores, se puede usar en el return
        //yield para retornar valores en switch
        //switch exhaustivo: evalua todos los casos, no se pone default
        return switch (clientEjb.login(client.getEmail(), client.getPassword())) {
            case null ->
                null;
            case ClientEjb.Login.LOGIN_SUCCESS -> {
                if (!(client.getEmail().equals("admin"))) {
                    yield goShop();
                } else {
                    initClients();
                    yield goAdminPanel();
                }
            }
            case ClientEjb.Login.LOGIN_PASSWD_FAILURE -> {
                errores.add("password-is-incorrect");
                yield null;
            }
            case ClientEjb.Login.LOGIN_EMAIL_FAILURE -> {
                errores.add("email-no-exist");
                yield null;
            }
        };
    }

    public String register() {
        errores.clear();
        if (this.validatePassword()) {
            return switch (clientEjb.register(client.getName(), client.getPassword(), client.getEmail())) {
                case null ->
                    null;
                case ClientEjb.Register.REGISTER_SUCCESS -> {
                    client = new Client();
                    FacesContext.getCurrentInstance().addMessage("form:register", new FacesMessage(FacesMessage.SEVERITY_INFO, "Se ha registrado correctamente", null));
                    yield null;
                }
                case ClientEjb.Register.REGISTER_EMAIL_IN_USE -> {
                    errores.add("email-already-exists");
                    yield null;
                }
                case ClientEjb.Register.FIELDS_EMPTY -> {
                    errores.add("fields-empty");
                    yield null;
                }
            };
        } else {
            errores.add("password-doesnt-match");
            return null;
        }
    }

    public boolean validatePassword() {
        return cpassword.equals(client.getPassword());
    }

    public String goShop() {
        errores.clear();
        return "home";
    }

    public String goAdminPanel() {
        errores.clear();
        return "adminPanel";
    }

    public String goLogin() {
        errores.clear();
        return "login";
    }

    public String goRegister() {
        errores.clear();
        return "register";
    }

    public boolean hasError(String error) {
        return errores.contains(error);
    }

    public Collection<Client> getClients() {
        return clients;
    }

    public void setClients(Collection<Client> clients) {
        this.clients = clients;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCpassword() {
        return cpassword;
    }

    public void setCpassword(String cpassword) {
        this.cpassword = cpassword;
    }

    public List<String> getErrores() {
        return errores;
    }

    public void setErrores(List<String> errores) {
        this.errores = errores;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }
}
